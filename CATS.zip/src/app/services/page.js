import { getServices } from "@/lib/getServices";
import ServiceCard from "@/components/common/ServiceCard";
import Header from "@/components/common/Header";
import MainLayout from "@/components/MainLayout";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { Slash } from "lucide-react";

export default async function ServicePage() {
  const services = await getServices(); // Fetch data on the server

  return (
    <>
      
        <section>
          <Header />
        </section>
        <section>
          <div className=" w-full bg-[#f4e4c9] py-4">
            <div className="max-w-screen-xl mx-auto">
              <h1 className="text-3xl font-bold mb-4 text-[#a58255] ">
                Services
              </h1>
              <div>
                <Breadcrumb>
                  <BreadcrumbList>
                    <BreadcrumbItem>
                      <BreadcrumbLink href="/">Home</BreadcrumbLink>
                    </BreadcrumbItem>
                    <BreadcrumbSeparator>
                      <Slash />
                    </BreadcrumbSeparator>
                    <BreadcrumbItem>
                      <BreadcrumbLink href="/services">Services</BreadcrumbLink>
                    </BreadcrumbItem>
                  </BreadcrumbList>
                </Breadcrumb>
              </div>
            </div>
          </div>
        </section>
        <section> 
          <div className="max-w-screen-xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {services.map((service) => (
                <ServiceCard key={service.id} service={service} />
              ))}
            </div>
          </div>
          </section> 
     
    </>
  );
}

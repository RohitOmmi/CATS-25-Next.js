export const SLIDER_IMAGE_BASE_PATH =
  "https://guprojects.gitam.edu/catscms2/public/slider/";

(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_components_DateTimeFormWrapper_454d32.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_components_DateTimeFormWrapper_454d32.js",
  "chunks": [
    "static/chunks/node_modules_9ed823._.js",
    "static/chunks/src_components_DateTimeFormWrapper_69df2b.js",
    "static/chunks/src_components_DateTimeFormWrapper_c615ae.js"
  ],
  "source": "dynamic"
});

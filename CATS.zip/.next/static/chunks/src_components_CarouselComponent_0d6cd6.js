(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_components_CarouselComponent_0d6cd6.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_components_CarouselComponent_0d6cd6.js",
  "chunks": [
    "static/chunks/_7c2867._.js"
  ],
  "source": "dynamic"
});

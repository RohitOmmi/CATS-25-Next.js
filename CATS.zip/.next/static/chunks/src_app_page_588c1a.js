(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_588c1a.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_588c1a.js",
  "chunks": [
    "static/chunks/node_modules_next_87d10c._.js",
    "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7._.js",
    "static/chunks/node_modules_react-icons_go_index_mjs_af0fd2._.js",
    "static/chunks/node_modules_react-icons_io5_index_mjs_39106f._.js",
    "static/chunks/node_modules_react-icons_lib_74ccc9._.js",
    "static/chunks/node_modules_8d8c90._.js",
    "static/chunks/src_09472e._.js",
    "static/chunks/src_components_CarouselComponent_2ed80d.js"
  ],
  "source": "dynamic"
});

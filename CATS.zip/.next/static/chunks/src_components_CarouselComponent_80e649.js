(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/src_components_CarouselComponent_80e649.js", {

"[project]/src/components/CarouselComponent.js [app-client] (ecmascript, async loader)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__((__turbopack_import__) => {
    return Promise.all([
  "static/chunks/node_modules_react-icons_io5_index_mjs_39106f._.js",
  "static/chunks/node_modules_fb2519._.js",
  "static/chunks/src_bad53f._.js",
  "static/chunks/src_components_CarouselComponent_891f48.js"
].map((chunk) => __turbopack_load__(chunk))).then(() => {
        return __turbopack_import__("[project]/src/components/CarouselComponent.js [app-client] (ecmascript)");
    });
});
}}),
}]);
(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_contact_page_588c1a.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_contact_page_588c1a.js",
  "chunks": [
    "static/chunks/node_modules_next_1f5c02._.js",
    "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7._.js",
    "static/chunks/node_modules_react-icons_go_index_mjs_af0fd2._.js",
    "static/chunks/node_modules_react-icons_lib_74ccc9._.js",
    "static/chunks/node_modules_8ca1f3._.js",
    "static/chunks/src_325905._.js"
  ],
  "source": "dynamic"
});

(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_components_CarouselComponent_a7e089.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_components_CarouselComponent_a7e089.js",
  "chunks": [
    "static/chunks/_41d4d1._.js"
  ],
  "source": "dynamic"
});

(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_search_page_588c1a.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_search_page_588c1a.js",
  "chunks": [
    "static/chunks/_c55f1e._.js"
  ],
  "source": "dynamic"
});

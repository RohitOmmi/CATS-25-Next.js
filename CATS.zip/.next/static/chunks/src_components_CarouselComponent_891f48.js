(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_components_CarouselComponent_891f48.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_components_CarouselComponent_891f48.js",
  "chunks": [
    "static/chunks/node_modules_react-icons_io5_index_mjs_39106f._.js",
    "static/chunks/node_modules_fb2519._.js",
    "static/chunks/src_bad53f._.js"
  ],
  "source": "dynamic"
});
